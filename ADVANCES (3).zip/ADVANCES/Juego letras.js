// Preguntas con imágenes y respuestas correctas
const questions = [
    { image: "imagenes/abeja.png", answer: "A" },
    { image: "imagenes/bola.png", answer: "B" },
    { image: "imagenes/casa.png", answer: "C" },
    { image: "imagenes/dado.png", answer: "D" }
];

let currentQuestion = 0; // Índice de la pregunta actual

// Función para cargar la pregunta
function loadQuestion() {
    const questionData = questions[currentQuestion];
    document.getElementById("letter-image").src = questionData.image;
    document.getElementById("message").textContent = "";
    document.getElementById("next-btn").style.display = "none";
}

// Función para verificar la respuesta del jugador
function checkAnswer(selectedLetter) {
    const correctAnswer = questions[currentQuestion].answer;
    const message = document.getElementById("message");

    if (selectedLetter === correctAnswer) {
        message.textContent = "✅ ¡Correcto!";
        message.style.color = "green";
        document.getElementById("next-btn").style.display = "block";
    } else {
        message.textContent = "❌ Intenta de nuevo";
        message.style.color = "red";
    }
}

// Función para avanzar a la siguiente pregunta
function nextQuestion() {
    currentQuestion++;

    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        document.getElementById("question").textContent = "🎉 ¡Felicidades, completaste el juego!";
        document.getElementById("image-container").style.display = "none";
        document.querySelector(".options").style.display = "none";
        document.getElementById("next-btn").style.display = "none";
    }
}

// Cargar la primera pregunta cuando la página se abra
document.addEventListener("DOMContentLoaded", loadQuestion);
