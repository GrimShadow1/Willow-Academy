document.addEventListener("DOMContentLoaded", function () {
    // Seleccionamos el botón "Juegos"
    const juegosMenuItem = document.querySelector(".menu-item a[href='#']"); // Buscar el enlace del menú "Juegos"

    if (juegosMenuItem) {
        // Evita que se abra el submenú
        juegosMenuItem.addEventListener("click", function (event) {
            event.preventDefault(); // Cancela el comportamiento predeterminado
            window.location.href = "juegos.html"; // Redirige a la página de juegos
        });

        // Eliminar el submenú de "Juegos"
        const submenu = juegosMenuItem.nextElementSibling;
        if (submenu) {
            submenu.remove();
        }
    }
});
