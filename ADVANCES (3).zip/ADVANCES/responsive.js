document.addEventListener("DOMContentLoaded", function () {
    // Función para ajustar el tamaño de los elementos según la pantalla
    function ajustarElementos() {
        const contenedor = document.querySelector(".container");
        const tarjetas = document.querySelectorAll(".card");
        const botones = document.querySelectorAll("button");

        // Ajustamos el ancho del contenedor
        if (window.innerWidth < 600) {
            contenedor.style.maxWidth = "100%";
            tarjetas.forEach(card => {
                card.style.width = "100%"; // Tarjetas ocupan el ancho en móviles
            });
            botones.forEach(btn => {
                btn.style.fontSize = "16px"; // Botones más pequeños en pantallas chicas
            });
        } else {
            contenedor.style.maxWidth = "800px";
            tarjetas.forEach(card => {
                card.style.width = "350px"; // Mantiene un tamaño adecuado en pantallas grandes
            });
            botones.forEach(btn => {
                btn.style.fontSize = "18px"; // Botones más grandes en PC/tablets
            });
        }
    }

    // Llamamos a la función al cargar la página y cuando se cambia el tamaño de la ventana
    ajustarElementos();
    window.addEventListener("resize", ajustarElementos);
});
