document.getElementById("btn-juego").addEventListener("click", function () {
    window.location.href = "./JUEGO NUMEROS.html";
});
