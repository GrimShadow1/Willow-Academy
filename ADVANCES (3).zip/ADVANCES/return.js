document.addEventListener("DOMContentLoaded", function () {
    const regresarBtn = document.createElement("a");
    regresarBtn.textContent = "🔙 Regresar";
    regresarBtn.href = "javascript:void(0)";
    regresarBtn.classList.add("btn-regresar");
    regresarBtn.onclick = function () {
        window.history.back(); // Regresa a la página anterior
    };

    document.body.insertBefore(regresarBtn, document.body.firstChild);
});
