// search bar.js

document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("search");

    searchInput.addEventListener("input", function () {
        const searchTerm = searchInput.value.trim().toLowerCase();
        removeHighlights(); // Elimina los resaltados previos

        if (searchTerm) {
            highlightText(document.body, searchTerm);
        }
    });

    function highlightText(element, searchTerm) {
        if (element.nodeType === 3) { // Nodo de texto
            const text = element.nodeValue.toLowerCase();
            const parent = element.parentNode;

            let startIndex = text.indexOf(searchTerm);
            if (startIndex !== -1) {
                const originalText = element.nodeValue;
                const highlightedText = document.createElement("span");

                highlightedText.className = "highlight";
                highlightedText.textContent = originalText.substring(startIndex, startIndex + searchTerm.length);

                const beforeText = document.createTextNode(originalText.substring(0, startIndex));
                const afterText = document.createTextNode(originalText.substring(startIndex + searchTerm.length));

                parent.replaceChild(afterText, element);
                parent.insertBefore(highlightedText, afterText);
                parent.insertBefore(beforeText, highlightedText);
            }
        } else {
            element.childNodes.forEach(child => highlightText(child, searchTerm));
        }
    }

    function removeHighlights() {
        document.querySelectorAll(".highlight").forEach(element => {
            element.outerHTML = element.textContent; // Restaura el texto original
        });
    }
});
