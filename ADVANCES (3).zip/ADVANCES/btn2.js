document.getElementById("btn-juegos").addEventListener("click", function () {
    window.location.href = "./Juego colores.html";
});
