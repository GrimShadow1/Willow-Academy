let originalTexts = [];

function saveOriginalTexts() {
  originalTexts = [];
  const allElements = document.body.querySelectorAll("*");

  allElements.forEach(el => {
    const isLeaf = el.children.length === 0;

    // TEXTOS VISIBLES Y OCULTOS
    if (isLeaf && el.textContent.trim()) {
      originalTexts.push({ element: el, type: 'text', original: el.textContent.trim() });
    }

    // placeholder, title, alt también
    if (el.placeholder) {
      originalTexts.push({ element: el, type: 'placeholder', original: el.placeholder });
    }
    if (el.title) {
      originalTexts.push({ element: el, type: 'title', original: el.title });
    }
    if (el.alt) {
      originalTexts.push({ element: el, type: 'alt', original: el.alt });
    }
  });
}

async function translateText(text, targetLang = 'en') {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
  try {
    const response = await fetch(url);
    const data = await response.json();
    return data[0][0][0];
  } catch (error) {
    console.error('Error al traducir:', error);
    return text;
  }
}

async function translatePage(lang) {
  if (originalTexts.length === 0) {
    saveOriginalTexts();
  }

  for (const item of originalTexts) {
    const { element, type, original } = item;
    if (lang === 'es') {
      applyTranslation(element, type, original);
    } else {
      const translated = await translateText(original, lang);
      applyTranslation(element, type, translated);
    }
  }
}

function applyTranslation(element, type, text) {
  switch (type) {
    case 'text':
      element.textContent = text;
      break;
    case 'placeholder':
      element.placeholder = text;
      break;
    case 'title':
      element.title = text;
      break;
    case 'alt':
      element.alt = text;
      break;
  }
}

function setLanguage(lang) {
  localStorage.setItem('language', lang);
  translatePage(lang);
}

function detectLanguage() {
  const savedLang = localStorage.getItem('language');
  const browserLang = navigator.language.slice(0, 2);
  const langToUse = savedLang || (['es', 'en', 'de'].includes(browserLang) ? browserLang : 'es');

  // Esperamos dos veces para asegurarnos que el menú esté cargado
  setTimeout(() => {
    saveOriginalTexts();
    translatePage(langToUse);
  }, 200);

  // Un segundo chequeo por si menús se abren por scripts o eventos
  setTimeout(() => {
    saveOriginalTexts();
    translatePage(langToUse);
  }, 1000);
}

function insertLanguageButtons() {
  const div = document.createElement('div');
  div.className = 'buttons';
  div.style.position = 'fixed';
  div.style.top = '10px';
  div.style.right = '10px';
  div.style.zIndex = '9999';
  div.innerHTML = `
    <button onclick="setLanguage('es')" title="Español" style="border:none;background:none;cursor:pointer;">
      <img src="img/es.png" alt="Español" width="30">
    </button>
    <button onclick="setLanguage('en')" title="English" style="border:none;background:none;cursor:pointer;">
      <img src="img/en.png" alt="English" width="30">
    </button>
    <button onclick="setLanguage('de')" title="Deutsch" style="border:none;background:none;cursor:pointer;">
      <img src="img/de.png" alt="Deutsch" width="30">
    </button>
  `;
  document.body.appendChild(div);
}

window.addEventListener('DOMContentLoaded', () => {
  insertLanguageButtons();
  detectLanguage();
});
