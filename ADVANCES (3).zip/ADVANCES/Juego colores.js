// Preguntas con nombres de colores y respuestas correctas
const questions = [
    { color: "Rojo", answer: "rojo" },
    { color: "Azul", answer: "azul" },
    { color: "Verde", answer: "verde" },
    { color: "Amarillo", answer: "amarillo" }
];

let currentQuestion = 0; // Índice de la pregunta actual

// Función para cargar la pregunta
function loadQuestion() {
    const questionData = questions[currentQuestion];
    document.getElementById("color-name").textContent = questionData.color;
    document.getElementById("message").textContent = "";
    document.getElementById("next-btn").style.display = "none";
}

// Función para verificar la respuesta del jugador
function checkAnswer(selectedColor) {
    const correctAnswer = questions[currentQuestion].answer;
    const message = document.getElementById("message");

    if (selectedColor === correctAnswer) {
        message.textContent = "✅ ¡Correcto!";
        message.style.color = "green";
        document.getElementById("next-btn").style.display = "block";
    } else {
        message.textContent = "❌ Intenta de nuevo";
        message.style.color = "red";
    }
}

// Función para avanzar a la siguiente pregunta
function nextQuestion() {
    currentQuestion++;

    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        document.getElementById("question").textContent = "🎉 ¡Felicidades, completaste el juego!";
        document.getElementById("color-box").style.display = "none";
        document.querySelector(".options").style.display = "none";
        document.getElementById("next-btn").style.display = "none";
    }
}

// Cargar la primera pregunta cuando la página se abra
document.addEventListener("DOMContentLoaded", loadQuestion);
