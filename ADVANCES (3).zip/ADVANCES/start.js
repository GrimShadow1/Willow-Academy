document.addEventListener("DOMContentLoaded", function () {
    const inicioBtn = document.createElement("a");
    inicioBtn.textContent = "🏠 Inicio";
    inicioBtn.href = "prue.html"; // Cambia la URL si el archivo principal tiene otro nombre
    inicioBtn.classList.add("btn-inicio");

    document.body.insertBefore(inicioBtn, document.body.firstChild);
});
