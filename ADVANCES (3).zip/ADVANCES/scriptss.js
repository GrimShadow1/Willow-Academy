// Esperamos a que la página cargue completamente antes de ejecutar el código
document.addEventListener("DOMContentLoaded", function () {
    const menuItems = document.querySelectorAll(".menu-item");

    menuItems.forEach(item => {
        // Solo mostramos submenús cuando hay un `<ul>` dentro del menú
        const submenu = item.querySelector(".submenu");
        if (submenu) {
            item.addEventListener("mouseenter", function () {
                submenu.style.visibility = "visible";
                submenu.style.opacity = "1";
            });

            item.addEventListener("mouseleave", function () {
                submenu.style.visibility = "hidden";
                submenu.style.opacity = "0";
            });
        }
    });

    // Hacemos que los juegos en la pantalla principal sigan funcionando
    const juegos = document.querySelectorAll(".card button");
    juegos.forEach(juego => {
        juego.addEventListener("click", function (event) {
            event.stopPropagation(); // Evita que el menú afecte a los botones
        });
    });
});