document.addEventListener("DOMContentLoaded", function () {
    // Lista de juegos
    const juegos = [
        { nombre: "Juego de Números", imagen: "img/0.png", enlace: "Juego numeros.html" },
        { nombre: "Juego de Colores", imagen: "img/1.jpg", enlace: "Juego colores.html" },
        { nombre: "Juego de Figuras", imagen: "img/2.jpg", enlace: "Juego de figuras.html" },
        { nombre: "Juego de Letras", imagen: "img/3.jpg", enlace: "Juego letras.html" },
        { nombre: "Juego de Animales", imagen: "img/4.avif", enlace: "Juego de animales.html" },
        { nombre: "Juego de Frutas", imagen: "img/5.jpg", enlace: "Juego de frutas.html" }
    ];

    // Contenedor donde se insertarán los juegos
    const container = document.getElementById("games-container");

    // Generar dinámicamente cada juego
    juegos.forEach(juego => {
        const juegoCard = document.createElement("div");
        juegoCard.classList.add("juego-card");

        const img = document.createElement("img");
        img.src = juego.imagen;
        img.alt = juego.nombre;

        const boton = document.createElement("button");
        boton.textContent = juego.nombre;
        boton.onclick = function () {
            window.location.href = juego.enlace;
        };

        juegoCard.appendChild(img);
        juegoCard.appendChild(boton);
        container.appendChild(juegoCard);
    });
});
